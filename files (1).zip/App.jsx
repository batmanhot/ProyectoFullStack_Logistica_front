import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import InventoryPage from './modules/inventory/InventoryPage';
import InboundPage from './modules/inventory/InboundPage';
import { Toaster } from 'react-hot-toast';
import OutboundPage from './modules/inventory/OutboundPage';
import TransferPage from './modules/inventory/TransferPage';
import ReportsPage from './modules/reports/ReportsPage';
import { AuthProvider, useAuth } from './context/AuthContext';
import { InventoryProvider } from './context/InventoryContext';
import LoginPage from './modules/auth/LoginPage';
import CatalogPage from './modules/catalog/CatalogPage';
import CategoriesPage from './modules/catalog/CategoriesPage';
import PartnersPage from './modules/partners/PartnersPage';
import BatchPage from './modules/batches/BatchPage';
import TransportersPage from './modules/partners/TransportersPage';
import LocationsPage from './modules/locations/LocationsPage';
import WarehouseMapPage from './modules/locations/WarehouseMapPage';
import DashboardPage from './modules/dashboard/DashboardPage';
import { LocationsProvider } from './context/LocationsContext';

const AppContent = () => {
  const { user } = useAuth();

  if (!user) return <LoginPage />;

  return (
    <InventoryProvider>
      <LocationsProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/inventario" element={<InventoryPage />} />
            <Route path="/catalogo" element={<CatalogPage />} />
            <Route path="/categorias" element={<CategoriesPage />} />
            <Route path="/lotes" element={<BatchPage />} />
            <Route path="/transportistas" element={<TransportersPage />} />
            <Route path="/ubicaciones" element={<LocationsPage />} />
            <Route path="/mapa-almacen" element={<WarehouseMapPage />} />
            <Route path="/directorio" element={<PartnersPage />} />
            <Route path="/clientes" element={<PartnersPage initialTab="Cliente" />} />
            <Route path="/proveedores" element={<PartnersPage initialTab="Proveedor" />} />
            <Route path="/entradas" element={<InboundPage />} />
            <Route path="/salidas" element={<OutboundPage />} />
            <Route path="/transferencias" element={<TransferPage />} />
            <Route path="/reportes" element={<ReportsPage />} />
          </Routes>
        </Layout>
      </LocationsProvider>
    </InventoryProvider>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Toaster position="top-right" />
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;
