import React, { createContext, useState, useContext, useCallback } from 'react';

// ---------------------------------------------------------------------------
// Usuarios del sistema (simulados — reemplazar por API en producción)
// Las contraseñas están "hasheadas" con una función simple para no tenerlas
// en texto plano. En producción usar bcrypt en el servidor + JWT.
// ---------------------------------------------------------------------------
const hashPassword = (password) => {
    // Simple hash determinístico para entorno sin backend.
    // NO usar en producción real — usar bcrypt server-side.
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
        hash = ((hash << 5) - hash) + password.charCodeAt(i);
        hash |= 0;
    }
    return hash.toString(16);
};

const USERS_DB = [
    {
        id: '1',
        username: 'admin',
        passwordHash: hashPassword('Admin2024!'),
        name: 'Administrador General',
        role: 'admin',
        email: 'admin@logiweb.pe',
        permissions: ['*'], // Acceso total
    },
    {
        id: '2',
        username: 'operador',
        passwordHash: hashPassword('Oper2024!'),
        name: 'Operador de Almacén',
        role: 'operador',
        email: 'operador@logiweb.pe',
        permissions: ['inventario', 'entradas', 'salidas', 'transferencias', 'reportes'],
    },
    {
        id: '3',
        username: 'supervisor',
        passwordHash: hashPassword('Super2024!'),
        name: 'Supervisor Logístico',
        role: 'supervisor',
        email: 'supervisor@logiweb.pe',
        permissions: ['inventario', 'entradas', 'salidas', 'transferencias', 'reportes', 'catalogo', 'lotes'],
    },
];

// Mapa de permisos por rol para usar en componentes
export const ROLE_PERMISSIONS = {
    admin:      { label: 'Administrador', color: 'bg-red-100 text-red-700',    canManageMasters: true,  canViewReports: true,  canDelete: true  },
    supervisor: { label: 'Supervisor',    color: 'bg-blue-100 text-blue-700',  canManageMasters: true,  canViewReports: true,  canDelete: false },
    operador:   { label: 'Operador',      color: 'bg-green-100 text-green-700',canManageMasters: false, canViewReports: true,  canDelete: false },
};

// ---------------------------------------------------------------------------
const AuthContext = createContext();

const SESSION_KEY = 'logi_session';

export const AuthProvider = ({ children }) => {
    // Restaurar sesión desde localStorage al recargar
    const [user, setUser] = useState(() => {
        try {
            const saved = localStorage.getItem(SESSION_KEY);
            return saved ? JSON.parse(saved) : null;
        } catch {
            return null;
        }
    });

    const login = useCallback((username, password) => {
        const inputHash = hashPassword(password);
        const found = USERS_DB.find(
            (u) => u.username === username && u.passwordHash === inputHash
        );
        if (!found) return { success: false, message: 'Usuario o contraseña incorrectos.' };

        const sessionUser = {
            id:          found.id,
            username:    found.username,
            name:        found.name,
            role:        found.role,
            email:       found.email,
            permissions: found.permissions,
            loginAt:     new Date().toISOString(),
        };
        setUser(sessionUser);
        localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
        return { success: true };
    }, []);

    const logout = useCallback(() => {
        setUser(null);
        localStorage.removeItem(SESSION_KEY);
    }, []);

    // Verificar si el usuario tiene permiso sobre un módulo
    const hasPermission = useCallback((module) => {
        if (!user) return false;
        if (user.permissions.includes('*')) return true;
        return user.permissions.includes(module);
    }, [user]);

    return (
        <AuthContext.Provider value={{ user, login, logout, hasPermission, ROLE_PERMISSIONS }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth must be used within AuthProvider');
    return ctx;
};