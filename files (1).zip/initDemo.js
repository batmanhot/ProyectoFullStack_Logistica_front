/**
 * initDemo.js — Inicializador de datos demo con versionado.
 *
 * Si la versión guardada en localStorage es menor a DEMO_VERSION,
 * limpia todo y carga el dataset nuevo automáticamente.
 *
 * Para forzar recarga: localStorage.removeItem('sp_demo_version') + reload.
 */

const DEMO_VERSION = '2.3.0'   // ← incrementar cuando cambie el dataset demo

const ALL_KEYS = [
  'sp_config','sp_productos','sp_categorias','sp_almacenes',
  'sp_proveedores','sp_movimientos','sp_ordenes','sp_usuarios',
  'sp_ajustes','sp_devoluciones','sp_transferencias',
  'sp_cotizaciones','sp_inv_fisico','sp_notif','sp_alertas_leidas',
  // NO borrar 'sp_session' — el usuario pierde sesión si lo hacemos
]

export function initDemoData(storageFns) {
  const savedVersion = localStorage.getItem('sp_demo_version')

  if (savedVersion === DEMO_VERSION) return  // ya está al día

  console.info(`[StockPro] Cargando dataset demo v${DEMO_VERSION} (anterior: ${savedVersion || 'ninguna'})`)

  // Limpiar datos anteriores (mantener sesión si hay)
  ALL_KEYS.forEach(k => localStorage.removeItem(k))

  // Forzar carga de cada entidad — las funciones guardan el demo al detectar localStorage vacío
  storageFns.getConfig()
  storageFns.getCategorias()
  storageFns.getAlmacenes()
  storageFns.getProveedores()
  storageFns.getProductos()
  storageFns.getMovimientos()
  storageFns.getOrdenes()
  storageFns.getUsuarios()
  storageFns.getAjustes()
  storageFns.getDevoluciones()
  storageFns.getTransferencias()
  storageFns.getCotizaciones()

  // Guardar versión actual
  localStorage.setItem('sp_demo_version', DEMO_VERSION)

  console.info('[StockPro] Dataset demo cargado correctamente ✓')
}
