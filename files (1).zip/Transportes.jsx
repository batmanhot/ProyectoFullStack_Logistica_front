import { useState, useEffect, useMemo } from 'react'
import {
  Plus, Search, Edit2, Trash2, Truck, MapPin, Clock,
  CheckCircle, X, Eye, Navigation, Package, AlertTriangle,
  PlayCircle, Flag, RotateCcw, Users
} from 'lucide-react'
import { useApp } from '../store/AppContext'
import { formatCurrency, formatDate, fechaHoy, generarNumDoc } from '../utils/helpers'
import * as storage from '../services/storage'
import { Modal, ConfirmDialog, EmptyState, Badge, Btn, Field, Alert } from '../components/ui/index'

const SI  = 'w-full px-3 py-2 bg-[#1e2835] border border-white/[0.08] rounded-lg text-[13px] text-[#e8edf2] outline-none focus:border-[#00c896] focus:ring-2 focus:ring-[#00c896]/20 font-[inherit] placeholder-[#5f6f80]'
const SEL = SI + ' pr-8'

// ── Metadatos de estado de ruta ──────────────────────────
const ESTADO_RUTA = {
  PROGRAMADA:  { label:'Programada',  color:'neutral', icon:Clock       },
  EN_RUTA:     { label:'En Ruta',     color:'info',    icon:Navigation  },
  COMPLETADA:  { label:'Completada',  color:'success', icon:CheckCircle },
  INCOMPLETA:  { label:'Incompleta',  color:'warning', icon:AlertTriangle},
  CANCELADA:   { label:'Cancelada',   color:'danger',  icon:X           },
}

const ESTADO_PARADA = {
  PENDIENTE:  { label:'Pendiente',   color:'neutral' },
  EN_CAMINO:  { label:'En camino',   color:'info'    },
  ENTREGADO:  { label:'Entregado',   color:'success' },
  FALLIDO:    { label:'No entregado',color:'danger'  },
}

export default function Transportes() {
  const [tab, setTab] = useState('rutas')

  return (
    <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">

      {/* Tabs */}
      <div className="flex gap-0.5 border-b border-white/[0.08]">
        {[
          ['rutas',          'Rutas y Salidas',  Navigation ],
          ['seguimiento',    'Seguimiento',      Truck      ],
          ['transportistas', 'Transportistas',   Users      ],
        ].map(([id, label, Icon]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-[13px] font-medium border-b-2 -mb-px transition-all
              ${tab === id
                ? 'text-[#00c896] border-[#00c896]'
                : 'text-[#5f6f80] border-transparent hover:text-[#9ba8b6]'
              }`}>
            <Icon size={14}/>{label}
          </button>
        ))}
      </div>

      {tab === 'rutas'          && <TabRutas/>}
      {tab === 'seguimiento'    && <TabSeguimiento/>}
      {tab === 'transportistas' && <TabTransportistas/>}
    </div>
  )
}

// ════════════════════════════════════════════════════════
// TAB RUTAS Y SALIDAS
// ════════════════════════════════════════════════════════
function TabRutas() {
  const {
    rutas, despachos, transportistas, clientes, productos,
    recargarRutas, recargarDespachos, sesion, toast, simboloMoneda,
  } = useApp()

  const [modal,   setModal]   = useState(false)
  const [detalle, setDetalle] = useState(null)
  const [filtEst, setFiltEst] = useState('')
  const [busq,    setBusq]    = useState('')

  const filtered = useMemo(() => {
    let d = [...rutas]
    if (filtEst) d = d.filter(r => r.estado === filtEst)
    if (busq) {
      const q = busq.toLowerCase()
      d = d.filter(r =>
        r.numero?.toLowerCase().includes(q) ||
        transportistas.find(t => t.id === r.transportistaId)?.nombre?.toLowerCase().includes(q)
      )
    }
    return d
  }, [rutas, filtEst, busq, transportistas])

  const kpis = useMemo(() => ({
    programadas: rutas.filter(r => r.estado === 'PROGRAMADA').length,
    enRuta:      rutas.filter(r => r.estado === 'EN_RUTA').length,
    completadas: rutas.filter(r => r.estado === 'COMPLETADA').length,
    totalViajes: rutas.length,
  }), [rutas])

  const traNombre = id => transportistas.find(t => t.id === id)?.nombre || '—'
  const trPlaca   = id => transportistas.find(t => t.id === id)?.placa  || ''

  function iniciarRuta(ruta) {
    const actualizada = {
      ...ruta,
      estado: 'EN_RUTA',
      paradas: ruta.paradas.map(p => ({ ...p, estado: p.orden === 1 ? 'EN_CAMINO' : 'PENDIENTE' })),
    }
    storage.saveRuta(actualizada)
    // Cambiar despachos a DESPACHADO y descontar stock
    ruta.despachoIds.forEach(dId => {
      const des = despachos.find(d => d.id === dId)
      if (des && des.estado === 'LISTO') {
        const guia = des.guiaNumero || generarNumDoc('GR', '001')
        const ahora = fechaHoy()
        // Descontar stock por cada ítem del despacho
        des.items?.forEach(item => {
          const prod = storage.getProductoById(item.productoId).data
          if (!prod || item.cantidad > prod.stockActual) return
          try {
            const { procesarSalida } = require ? {} : { procesarSalida: null }
            // Reducir stock directamente
            const nuevoStock = Math.max(0, prod.stockActual - item.cantidad)
            const factor = prod.stockActual > 0 ? nuevoStock / prod.stockActual : 0
            const batches = (prod.batches || []).map(b => ({ ...b, cantidad: b.cantidad * factor })).filter(b => b.cantidad > 0.001)
            storage._actualizarBatchesProducto(prod.id, batches, nuevoStock)
            storage.registrarMovimiento({
              tipo:'SALIDA', productoId:item.productoId, almacenId:des.almacenId,
              cantidad:item.cantidad, costoUnitario:item.costoUnitario||0, costoTotal:item.costoUnitario*item.cantidad||0,
              lote:'', fecha:ahora,
              motivo:`Ruta ${ruta.numero} — ${guia}`,
              documento:guia, notas:'', usuarioId: sesion?.id||'usr1',
            })
          } catch(e) {}
        })
        storage.saveDespacho({ ...des, estado:'DESPACHADO', guiaNumero: guia, fechaDespacho: ahora })
      }
    })
    recargarRutas()
    recargarDespachos()
    toast(`Ruta ${ruta.numero} iniciada — ${ruta.despachoIds.length} despacho(s) en camino`, 'success')
  }

  function completarRuta(ruta) {
    const pendientes = ruta.paradas.filter(p => p.estado === 'PENDIENTE' || p.estado === 'EN_CAMINO').length
    const estado = pendientes === 0 ? 'COMPLETADA' : 'INCOMPLETA'
    storage.saveRuta({ ...ruta, estado, fechaRetorno: fechaHoy() })
    // Confirmar entrega de despachos entregados
    ruta.paradas.forEach(p => {
      const des = despachos.find(d => d.id === p.despachoId)
      if (des && p.estado === 'ENTREGADO' && des.estado !== 'ENTREGADO') {
        storage.saveDespacho({ ...des, estado:'ENTREGADO', fechaEntregaReal: fechaHoy() })
      }
    })
    recargarRutas()
    recargarDespachos()
    toast(`Ruta ${ruta.numero} ${estado === 'COMPLETADA' ? 'completada' : 'cerrada con incompletos'}`, estado === 'COMPLETADA' ? 'success' : 'warning')
    setDetalle(null)
  }

  function marcarParada(ruta, despachoId, nuevoEstado, obs='') {
    const paradas = ruta.paradas.map(p => {
      if (p.despachoId !== despachoId) return p
      const ahora = new Date().toTimeString().slice(0,5)
      return {
        ...p, estado: nuevoEstado,
        horaLlegada:  nuevoEstado === 'ENTREGADO' || nuevoEstado === 'FALLIDO' ? (p.horaLlegada || ahora) : p.horaLlegada,
        horaPartida:  nuevoEstado === 'ENTREGADO' || nuevoEstado === 'FALLIDO' ? ahora : null,
        observacion:  obs || p.observacion,
      }
    })
    // Avanzar siguiente parada a EN_CAMINO
    const sigIdx = paradas.findIndex((p, i) => p.estado === 'PENDIENTE' && i > paradas.findIndex(x => x.despachoId === despachoId))
    const paradasFinal = paradas.map((p, i) => i === sigIdx ? { ...p, estado:'EN_CAMINO' } : p)

    const actualizada = { ...ruta, paradas: paradasFinal }
    storage.saveRuta(actualizada)
    if (nuevoEstado === 'ENTREGADO') {
      const des = despachos.find(d => d.id === despachoId)
      if (des) storage.saveDespacho({ ...des, estado:'ENTREGADO', fechaEntregaReal: fechaHoy() })
    }
    recargarRutas()
    recargarDespachos()
    if (detalle?.id === ruta.id) setDetalle({ ...actualizada })
    toast(nuevoEstado === 'ENTREGADO' ? '✓ Entrega confirmada' : 'Parada marcada como no entregada', nuevoEstado === 'ENTREGADO' ? 'success' : 'warning')
  }

  return (
    <>
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {[
          ['Programadas',  kpis.programadas, '#5f6f80', Clock      ],
          ['En Ruta',      kpis.enRuta,      '#3b82f6', Navigation ],
          ['Completadas',  kpis.completadas, '#22c55e', CheckCircle],
          ['Total viajes', kpis.totalViajes, '#00c896', Truck      ],
        ].map(([l, v, color, Icon]) => (
          <div key={l} className="relative bg-[#161d28] border border-white/[0.08] rounded-xl px-5 py-4 overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-[3px] rounded-t-xl" style={{ background: color }}/>
            <div className="flex items-center gap-2 mb-2">
              <Icon size={13} style={{ color }} className="opacity-80"/>
              <span className="text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.05em]">{l}</span>
            </div>
            <div className="text-[28px] font-semibold text-[#e8edf2]">{v}</div>
          </div>
        ))}
      </div>

      {/* Tabla rutas */}
      <div className="bg-[#161d28] border border-white/[0.08] rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.06em]">Rutas de Entrega</span>
          <Btn variant="primary" size="sm" onClick={() => setModal(true)}>
            <Plus size={13}/> Nueva Ruta
          </Btn>
        </div>

        <div className="flex flex-wrap gap-2 mb-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#5f6f80] pointer-events-none"/>
            <input className={SI + ' pl-8'} placeholder="Buscar número, transportista..."
              value={busq} onChange={e => setBusq(e.target.value)}/>
          </div>
          <select className={SEL} style={{ width: 160 }} value={filtEst} onChange={e => setFiltEst(e.target.value)}>
            <option value="">Todos los estados</option>
            {Object.entries(ESTADO_RUTA).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          {(busq || filtEst) && <Btn variant="ghost" size="sm" onClick={() => { setBusq(''); setFiltEst('') }}>Limpiar</Btn>}
        </div>

        <div className="overflow-x-auto rounded-xl border border-white/[0.08]">
          <table className="w-full border-collapse text-[13px]">
            <thead><tr>
              {['N° Ruta','Transportista','Placa/Vehículo','F. Salida','Hora','Paradas','Estado','Acciones'].map(h => (
                <th key={h} className="bg-[#1a2230] px-3.5 py-2.5 text-left text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.05em] border-b border-white/[0.08] whitespace-nowrap">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8}><EmptyState icon={Navigation} title="Sin rutas" description="Programa la primera ruta de entrega."/></td></tr>
              )}
              {filtered.map(ruta => {
                const meta = ESTADO_RUTA[ruta.estado]
                const Icon = meta.icon
                const entregadas = ruta.paradas.filter(p => p.estado === 'ENTREGADO').length
                const tra = transportistas.find(t => t.id === ruta.transportistaId)
                return (
                  <tr key={ruta.id} className="border-b border-white/[0.06] last:border-0 hover:bg-white/[0.02]">
                    <td className="px-3.5 py-2.5 font-mono text-[12px] font-semibold text-[#00c896]">{ruta.numero}</td>
                    <td className="px-3.5 py-2.5">
                      <div className="font-medium text-[#e8edf2]">{tra?.nombre || '—'}</div>
                      <div className="text-[11px] text-[#5f6f80]">{tra?.tipo === 'PROPIO' ? 'Propio' : 'Tercero'}</div>
                    </td>
                    <td className="px-3.5 py-2.5 text-[12px] text-[#9ba8b6]">
                      {tra?.placa ? <span className="font-mono">{tra.placa}</span> : '—'}
                      <div className="text-[11px] text-[#5f6f80] truncate max-w-[120px]">{tra?.vehiculo}</div>
                    </td>
                    <td className="px-3.5 py-2.5 font-mono text-[12px] text-[#9ba8b6]">{formatDate(ruta.fechaSalida)}</td>
                    <td className="px-3.5 py-2.5 font-mono text-[12px] text-[#9ba8b6]">{ruta.horaSalida}</td>
                    <td className="px-3.5 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[13px] font-semibold text-[#e8edf2]">{entregadas}/{ruta.paradas.length}</span>
                        <div className="w-16 h-1.5 bg-[#1a2230] rounded-full overflow-hidden">
                          <div className="h-full bg-[#00c896] rounded-full transition-all"
                            style={{ width: ruta.paradas.length ? `${(entregadas/ruta.paradas.length)*100}%` : '0%' }}/>
                        </div>
                      </div>
                    </td>
                    <td className="px-3.5 py-2.5">
                      <Badge variant={meta.color}><Icon size={9}/> {meta.label}</Badge>
                    </td>
                    <td className="px-3.5 py-2.5">
                      <div className="flex gap-1 items-center">
                        <Btn variant="ghost" size="icon" title="Ver detalle" onClick={() => setDetalle(ruta)}>
                          <Eye size={13}/>
                        </Btn>
                        {ruta.estado === 'PROGRAMADA' && (
                          <Btn variant="primary" size="sm" onClick={() => iniciarRuta(ruta)}>
                            <PlayCircle size={12}/> Iniciar
                          </Btn>
                        )}
                        {ruta.estado === 'EN_RUTA' && (
                          <Btn variant="secondary" size="sm" onClick={() => setDetalle(ruta)}>
                            <Navigation size={12}/> Gestionar
                          </Btn>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal nueva ruta */}
      {modal && (
        <ModalNuevaRuta
          onClose={() => setModal(false)}
          onSave={data => { storage.saveRuta(data); recargarRutas(); setModal(false); toast(`Ruta ${data.numero} programada`, 'success') }}
          despachos={despachos} transportistas={transportistas} clientes={clientes}
        />
      )}

      {/* Modal detalle / gestión */}
      {detalle && (
        <ModalDetalleRuta
          ruta={detalle} despachos={despachos} clientes={clientes} transportistas={transportistas}
          onClose={() => setDetalle(null)}
          onIniciar={() => iniciarRuta(detalle)}
          onCompletar={() => completarRuta(detalle)}
          onMarcarParada={(dId, estado, obs) => marcarParada(detalle, dId, estado, obs)}
        />
      )}
    </>
  )
}

// ════════════════════════════════════════════════════════
// TAB SEGUIMIENTO
// ════════════════════════════════════════════════════════
function TabSeguimiento() {
  const { rutas, despachos, transportistas, clientes } = useApp()
  const [filtFecha, setFiltFecha] = useState(fechaHoy())

  const rutasActivas = useMemo(() =>
    rutas.filter(r => r.estado === 'EN_RUTA' || r.estado === 'PROGRAMADA')
  , [rutas])

  const rutasDia = useMemo(() =>
    rutas.filter(r => r.fechaSalida === filtFecha)
  , [rutas, filtFecha])

  const cliNombre = id => clientes.find(c => c.id === id)?.razonSocial?.slice(0,25) || '—'
  const traNombre = id => transportistas.find(t => t.id === id)?.nombre || '—'

  return (
    <div className="flex flex-col gap-5">

      {/* Rutas en tiempo real */}
      {rutasActivas.length > 0 && (
        <div className="bg-[#161d28] border border-[#00c896]/20 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-[#00c896] animate-pulse"/>
            <span className="text-[11px] font-semibold text-[#00c896] uppercase tracking-[0.06em]">
              En Tiempo Real — {rutasActivas.length} ruta(s) activa(s)
            </span>
          </div>
          <div className="flex flex-col gap-3">
            {rutasActivas.map(ruta => {
              const tra      = transportistas.find(t => t.id === ruta.transportistaId)
              const entregadas = ruta.paradas.filter(p => p.estado === 'ENTREGADO').length
              const total    = ruta.paradas.length
              const pct      = total > 0 ? Math.round((entregadas / total) * 100) : 0
              const meta     = ESTADO_RUTA[ruta.estado]
              const Icon     = meta.icon
              return (
                <div key={ruta.id} className="bg-[#1a2230] rounded-xl p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${ruta.estado === 'EN_RUTA' ? 'bg-blue-500/15' : 'bg-[#5f6f80]/15'}`}>
                          <Icon size={15} className={ruta.estado === 'EN_RUTA' ? 'text-blue-400' : 'text-[#5f6f80]'}/>
                        </div>
                        <div>
                          <div className="font-semibold text-[#e8edf2]">{ruta.numero}</div>
                          <div className="text-[11px] text-[#5f6f80]">
                            {tra?.nombre} {tra?.placa ? `· ${tra.placa}` : ''} · Salida: {ruta.horaSalida}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={meta.color}>{meta.label}</Badge>
                      <div className="text-[11px] text-[#5f6f80] mt-1">{entregadas}/{total} entregas</div>
                    </div>
                  </div>

                  {/* Barra de progreso */}
                  <div className="mb-3">
                    <div className="flex justify-between text-[11px] text-[#5f6f80] mb-1">
                      <span>Progreso de entregas</span>
                      <span className="text-[#00c896] font-semibold">{pct}%</span>
                    </div>
                    <div className="w-full h-2 bg-[#0e1117] rounded-full overflow-hidden">
                      <div className="h-full bg-[#00c896] rounded-full transition-all duration-500"
                        style={{ width: `${pct}%` }}/>
                    </div>
                  </div>

                  {/* Paradas */}
                  <div className="flex flex-col gap-1.5">
                    {ruta.paradas.map((parada, idx) => {
                      const des     = despachos.find(d => d.id === parada.despachoId)
                      const pMeta   = ESTADO_PARADA[parada.estado]
                      return (
                        <div key={parada.despachoId}
                          className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                            parada.estado === 'EN_CAMINO' ? 'bg-blue-500/10 border border-blue-500/20' :
                            parada.estado === 'ENTREGADO' ? 'bg-green-500/5 border border-green-500/10 opacity-60' :
                            parada.estado === 'FALLIDO'   ? 'bg-red-500/10 border border-red-500/20' :
                            'bg-[#0e1117]/40 border border-white/[0.04]'
                          }`}>
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                            parada.estado === 'ENTREGADO' ? 'bg-green-500/20 text-green-400' :
                            parada.estado === 'EN_CAMINO' ? 'bg-blue-500/20 text-blue-400' :
                            parada.estado === 'FALLIDO'   ? 'bg-red-500/20 text-red-400' :
                            'bg-white/10 text-[#5f6f80]'
                          }`}>{idx + 1}</div>
                          <div className="flex-1 min-w-0">
                            <div className="text-[12px] font-medium text-[#e8edf2] truncate">
                              {cliNombre(des?.clienteId)}
                            </div>
                            <div className="text-[11px] text-[#5f6f80] truncate">{des?.direccionEntrega}</div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            {parada.horaLlegada && <span className="text-[11px] font-mono text-[#9ba8b6]">{parada.horaLlegada}</span>}
                            <Badge variant={pMeta.color}>{pMeta.label}</Badge>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Filtro por fecha */}
      <div className="bg-[#161d28] border border-white/[0.08] rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.06em]">
            Historial de Rutas por Fecha
          </span>
          <input type="date" className={SI} style={{ width: 160 }}
            value={filtFecha} onChange={e => setFiltFecha(e.target.value)}/>
        </div>

        {rutasDia.length === 0 ? (
          <EmptyState icon={Navigation} title="Sin rutas este día"
            description={`No hay rutas programadas para el ${formatDate(filtFecha)}.`}/>
        ) : (
          <div className="flex flex-col gap-3">
            {rutasDia.map(ruta => {
              const tra        = transportistas.find(t => t.id === ruta.transportistaId)
              const meta       = ESTADO_RUTA[ruta.estado]
              const Icon       = meta.icon
              const entregadas = ruta.paradas.filter(p => p.estado === 'ENTREGADO').length
              return (
                <div key={ruta.id} className="bg-[#1a2230] border border-white/[0.06] rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon size={16} className="text-[#9ba8b6]"/>
                      <div>
                        <div className="font-semibold text-[#e8edf2]">{ruta.numero}</div>
                        <div className="text-[11px] text-[#5f6f80]">
                          {tra?.nombre} · {ruta.horaSalida} → {ruta.horaRetorno || '—'}
                          · {entregadas}/{ruta.paradas.length} entregas
                          {ruta.kmRecorrido ? ` · ${ruta.kmRecorrido} km` : ''}
                        </div>
                      </div>
                    </div>
                    <Badge variant={meta.color}><Icon size={9}/> {meta.label}</Badge>
                  </div>
                  {ruta.observaciones && (
                    <p className="mt-2 text-[11px] text-[#9ba8b6] pl-7">{ruta.observaciones}</p>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ════════════════════════════════════════════════════════
// TAB TRANSPORTISTAS
// ════════════════════════════════════════════════════════
function TabTransportistas() {
  const { transportistas, recargarTransportistas } = useApp()
  const [modal,      setModal]      = useState(false)
  const [editando,   setEditando]   = useState(null)
  const [confirmDel, setConfirmDel] = useState(null)
  const [busq,       setBusq]       = useState('')

  const filtered = useMemo(() =>
    transportistas.filter(t =>
      !busq || t.nombre?.toLowerCase().includes(busq.toLowerCase()) || t.placa?.toLowerCase().includes(busq.toLowerCase())
    )
  , [transportistas, busq])

  function handleSave(data) {
    storage.saveTransportista(data)
    recargarTransportistas()
    setModal(false)
  }

  const kpis = {
    total:   transportistas.length,
    propios: transportistas.filter(t => t.tipo === 'PROPIO').length,
    terceros:transportistas.filter(t => t.tipo === 'TERCERO').length,
  }

  return (
    <>
      <div className="grid grid-cols-3 gap-3.5">
        {[
          ['Total',        kpis.total,    '#00c896'],
          ['Propios',      kpis.propios,  '#3b82f6'],
          ['Terceros',     kpis.terceros, '#f59e0b'],
        ].map(([l, v, color]) => (
          <div key={l} className="relative bg-[#161d28] border border-white/[0.08] rounded-xl px-5 py-4 overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-[3px] rounded-t-xl" style={{ background: color }}/>
            <div className="text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.05em] mb-2">{l}</div>
            <div className="text-[28px] font-semibold text-[#e8edf2]">{v}</div>
          </div>
        ))}
      </div>

      <div className="bg-[#161d28] border border-white/[0.08] rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.06em]">Transportistas</span>
          <Btn variant="primary" size="sm" onClick={() => { setEditando(null); setModal(true) }}>
            <Plus size={13}/> Nuevo
          </Btn>
        </div>
        <div className="relative mb-3 max-w-sm">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#5f6f80] pointer-events-none"/>
          <input className={SI + ' pl-8'} placeholder="Buscar nombre, placa..."
            value={busq} onChange={e => setBusq(e.target.value)}/>
        </div>
        <div className="overflow-x-auto rounded-xl border border-white/[0.08]">
          <table className="w-full border-collapse text-[13px]">
            <thead><tr>
              {['Nombre','Tipo','Placa','Vehículo','Teléfono','Licencia','Estado','Acciones'].map(h => (
                <th key={h} className="bg-[#1a2230] px-3.5 py-2.5 text-left text-[11px] font-semibold text-[#5f6f80] uppercase tracking-[0.05em] border-b border-white/[0.08] whitespace-nowrap">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8}><EmptyState icon={Truck} title="Sin transportistas" description="Agrega el primer transportista."/></td></tr>
              )}
              {filtered.map(t => (
                <tr key={t.id} className="border-b border-white/[0.06] last:border-0 hover:bg-white/[0.02]">
                  <td className="px-3.5 py-2.5 font-medium text-[#e8edf2]">{t.nombre}</td>
                  <td className="px-3.5 py-2.5">
                    <Badge variant={t.tipo === 'PROPIO' ? 'teal' : 'neutral'}>{t.tipo}</Badge>
                  </td>
                  <td className="px-3.5 py-2.5 font-mono text-[12px] text-[#9ba8b6]">{t.placa || '—'}</td>
                  <td className="px-3.5 py-2.5 text-[12px] text-[#9ba8b6]">{t.vehiculo || '—'}</td>
                  <td className="px-3.5 py-2.5 text-[12px] text-[#9ba8b6]">{t.telefono || '—'}</td>
                  <td className="px-3.5 py-2.5 font-mono text-[12px] text-[#9ba8b6]">{t.licencia || '—'}</td>
                  <td className="px-3.5 py-2.5"><Badge variant={t.activo ? 'success' : 'neutral'}>{t.activo ? 'Activo' : 'Inactivo'}</Badge></td>
                  <td className="px-3.5 py-2.5">
                    <div className="flex gap-1">
                      <Btn variant="ghost" size="icon" onClick={() => { setEditando(t); setModal(true) }}><Edit2 size={13}/></Btn>
                      <Btn variant="ghost" size="icon" className="text-red-400 hover:text-red-300" onClick={() => setConfirmDel(t.id)}><Trash2 size={13}/></Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && <ModalTransportista open onClose={() => { setModal(false); setEditando(null) }} editando={editando} onSave={handleSave}/>}
      <ConfirmDialog open={!!confirmDel} onClose={() => setConfirmDel(null)} danger
        title="Eliminar transportista" message="¿Eliminar este transportista?"
        onConfirm={() => { storage.deleteTransportista(confirmDel); recargarTransportistas(); setConfirmDel(null) }}/>
    </>
  )
}

// ── Modal Nueva Ruta ─────────────────────────────────────
function ModalNuevaRuta({ onClose, onSave, despachos, transportistas, clientes }) {
  const [form, setForm] = useState({ transportistaId:'', fechaSalida:fechaHoy(), horaSalida:'08:00', costoViaje:'', observaciones:'' })
  const [selDes, setSelDes] = useState([]) // despachoIds seleccionados
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const disponibles = despachos.filter(d => d.estado === 'LISTO')
  const cliNombre = id => clientes.find(c => c.id === id)?.razonSocial?.slice(0,30) || '—'

  function toggleDes(id) {
    setSelDes(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  function handleSave() {
    if (!form.transportistaId || selDes.length === 0) return
    const paradas = selDes.map((dId, i) => ({ despachoId:dId, orden:i+1, estado:'PENDIENTE', horaLlegada:null, horaPartida:null, observacion:'' }))
    onSave({ numero:generarNumDoc('RT','001'), estado:'PROGRAMADA', ...form, costoViaje:+form.costoViaje||0, despachoIds:selDes, paradas, fechaRetorno:null, horaRetorno:null, usuarioId:'usr1' })
  }

  return (
    <Modal open onClose={onClose} title="Programar Nueva Ruta de Entrega" size="lg"
      footer={<><Btn variant="secondary" onClick={onClose}>Cancelar</Btn><Btn variant="primary" disabled={!form.transportistaId||selDes.length===0} onClick={handleSave}><Navigation size={13}/> Programar Ruta</Btn></>}>

      <div className="grid grid-cols-2 gap-3.5">
        <Field label="Transportista *">
          <select className={SEL} value={form.transportistaId} onChange={e => f('transportistaId', e.target.value)}>
            <option value="">Seleccionar...</option>
            {transportistas.filter(t => t.activo).map(t => <option key={t.id} value={t.id}>{t.nombre} {t.placa ? `· ${t.placa}` : ''}</option>)}
          </select>
        </Field>
        <Field label="Fecha de Salida">
          <input type="date" className={SI} value={form.fechaSalida} onChange={e => f('fechaSalida', e.target.value)}/>
        </Field>
        <Field label="Hora de Salida">
          <input type="time" className={SI} value={form.horaSalida} onChange={e => f('horaSalida', e.target.value)}/>
        </Field>
        <Field label="Costo del Viaje (S/)">
          <input type="number" className={SI} value={form.costoViaje} onChange={e => f('costoViaje', e.target.value)} min="0" step="0.50"/>
        </Field>
      </div>

      <div className="text-[13px] font-semibold text-[#e8edf2]">
        Despachos a incluir
        <span className="ml-2 text-[11px] text-[#5f6f80] font-normal">Solo despachos en estado "Listo"</span>
      </div>

      {disponibles.length === 0 ? (
        <Alert variant="warning">No hay despachos en estado "Listo" para incluir en esta ruta. Avanza el estado de los despachos primero.</Alert>
      ) : (
        <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
          {disponibles.map(d => (
            <label key={d.id} className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
              selDes.includes(d.id) ? 'bg-[#00c896]/10 border-[#00c896]/40' : 'bg-[#1a2230] border-white/[0.06] hover:border-white/[0.12]'
            }`}>
              <input type="checkbox" checked={selDes.includes(d.id)} onChange={() => toggleDes(d.id)} className="accent-[#00c896]"/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[12px] text-[#00c896]">{d.numero}</span>
                  <span className="text-[12px] text-[#e8edf2] truncate">{cliNombre(d.clienteId)}</span>
                </div>
                <div className="text-[11px] text-[#5f6f80] truncate">{d.direccionEntrega}</div>
              </div>
              <span className="text-[11px] text-[#9ba8b6] font-mono shrink-0">{d.items?.length} ítem(s)</span>
            </label>
          ))}
        </div>
      )}

      <Field label="Observaciones">
        <textarea className={SI + ' resize-y min-h-[52px]'} value={form.observaciones}
          onChange={e => f('observaciones', e.target.value)} placeholder="Instrucciones para el conductor..."/>
      </Field>
    </Modal>
  )
}

// ── Modal Detalle / Gestión de Ruta ──────────────────────
function ModalDetalleRuta({ ruta, despachos, clientes, transportistas, onClose, onIniciar, onCompletar, onMarcarParada }) {
  const [obsParada, setObsParada] = useState({})
  const tra  = transportistas.find(t => t.id === ruta.transportistaId)
  const meta = ESTADO_RUTA[ruta.estado]
  const Icon = meta.icon
  const entregadas = ruta.paradas.filter(p => p.estado === 'ENTREGADO').length
  const cliNombre  = id => clientes.find(c => c.id === id)?.razonSocial || '—'

  return (
    <Modal open title={`Ruta ${ruta.numero}`} onClose={onClose} size="lg"
      footer={<>
        <Btn variant="secondary" onClick={onClose}>Cerrar</Btn>
        {ruta.estado === 'PROGRAMADA' && <Btn variant="primary" onClick={onIniciar}><PlayCircle size={14}/> Iniciar Ruta</Btn>}
        {ruta.estado === 'EN_RUTA'    && <Btn variant="success"  onClick={onCompletar}><Flag size={14}/> Cerrar Ruta</Btn>}
      </>}>

      {/* Info ruta */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {[
          ['Transportista', tra?.nombre || '—'],
          ['Placa / Vehículo', `${tra?.placa || '—'} · ${tra?.vehiculo || '—'}`],
          ['Fecha Salida', formatDate(ruta.fechaSalida)],
          ['Hora Salida', ruta.horaSalida],
          ['Estado', null],
          ['Progreso', `${entregadas}/${ruta.paradas.length} entregas`],
        ].map(([k, v]) => (
          <div key={k} className="bg-[#1a2230] rounded-lg px-3.5 py-2.5">
            <div className="text-[10px] text-[#5f6f80] uppercase tracking-wide mb-0.5">{k}</div>
            {k === 'Estado'
              ? <Badge variant={meta.color}><Icon size={9}/> {meta.label}</Badge>
              : <div className="text-[13px] font-medium text-[#e8edf2]">{v}</div>
            }
          </div>
        ))}
      </div>

      {/* Barra progreso */}
      <div className="mb-4">
        <div className="w-full h-2 bg-[#0e1117] rounded-full overflow-hidden">
          <div className="h-full bg-[#00c896] rounded-full transition-all"
            style={{ width: ruta.paradas.length ? `${(entregadas/ruta.paradas.length)*100}%` : '0%' }}/>
        </div>
      </div>

      {/* Paradas con acciones */}
      <div className="text-[13px] font-semibold text-[#e8edf2] mb-3">Paradas del viaje</div>
      <div className="flex flex-col gap-2.5">
        {ruta.paradas.map(parada => {
          const des   = despachos.find(d => d.id === parada.despachoId)
          const pMeta = ESTADO_PARADA[parada.estado]
          return (
            <div key={parada.despachoId} className={`p-4 rounded-xl border transition-all ${
              parada.estado === 'EN_CAMINO' ? 'bg-blue-500/10 border-blue-500/25' :
              parada.estado === 'ENTREGADO' ? 'bg-green-500/5 border-green-500/15 opacity-70' :
              parada.estado === 'FALLIDO'   ? 'bg-red-500/10 border-red-500/20' :
              'bg-[#1a2230] border-white/[0.06]'
            }`}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-start gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 mt-0.5 ${
                    parada.estado === 'ENTREGADO' ? 'bg-green-500/20 text-green-400' :
                    parada.estado === 'EN_CAMINO' ? 'bg-blue-500/20 text-blue-400' :
                    parada.estado === 'FALLIDO'   ? 'bg-red-500/20 text-red-400' :
                    'bg-white/10 text-[#5f6f80]'
                  }`}>{parada.orden}</div>
                  <div>
                    <div className="font-medium text-[#e8edf2]">{cliNombre(des?.clienteId)}</div>
                    <div className="text-[11px] text-[#5f6f80]">{des?.direccionEntrega}</div>
                    <div className="text-[11px] text-[#9ba8b6] mt-0.5">
                      {des?.numero} · {des?.items?.length} ítem(s) · {formatCurrency(des?.total||0, 'S/')}
                    </div>
                    {parada.horaLlegada && (
                      <div className="text-[11px] text-[#5f6f80] mt-0.5">
                        Llegada: {parada.horaLlegada}{parada.horaPartida ? ` · Partida: ${parada.horaPartida}` : ''}
                      </div>
                    )}
                  </div>
                </div>
                <Badge variant={pMeta.color}>{pMeta.label}</Badge>
              </div>

              {/* Acciones para parada activa */}
              {ruta.estado === 'EN_RUTA' && (parada.estado === 'EN_CAMINO' || parada.estado === 'PENDIENTE') && (
                <div className="mt-3 pt-3 border-t border-white/[0.06]">
                  <input className={SI + ' mb-2'} placeholder="Observación (opcional)"
                    value={obsParada[parada.despachoId] || ''}
                    onChange={e => setObsParada(p => ({ ...p, [parada.despachoId]: e.target.value }))}/>
                  <div className="flex gap-2">
                    <Btn variant="primary" size="sm"
                      onClick={() => onMarcarParada(parada.despachoId, 'ENTREGADO', obsParada[parada.despachoId] || '')}>
                      <CheckCircle size={12}/> Confirmar Entrega
                    </Btn>
                    <Btn variant="ghost" size="sm" className="text-red-400 hover:text-red-300"
                      onClick={() => onMarcarParada(parada.despachoId, 'FALLIDO', obsParada[parada.despachoId] || 'No se pudo entregar')}>
                      <X size={12}/> No Entregado
                    </Btn>
                  </div>
                </div>
              )}

              {parada.observacion && (
                <div className="mt-2 text-[11px] text-[#9ba8b6] italic">{parada.observacion}</div>
              )}
            </div>
          )
        })}
      </div>
    </Modal>
  )
}

// ── Modal Transportista ──────────────────────────────────
function ModalTransportista({ open, onClose, editando, onSave }) {
  const init = { nombre:'', tipo:'PROPIO', placa:'', vehiculo:'', telefono:'', email:'', licencia:'', activo:true }
  const [form, setForm] = useState(init)
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }))

  useEffect(() => {
    setForm(editando ? { ...init, ...editando } : init)
  }, [editando, open])

  return (
    <Modal open={open} onClose={onClose} title={editando ? 'Editar Transportista' : 'Nuevo Transportista'} size="md"
      footer={<><Btn variant="secondary" onClick={onClose}>Cancelar</Btn><Btn variant="primary" disabled={!form.nombre.trim()} onClick={() => form.nombre.trim() && onSave(form)}>Guardar</Btn></>}>
      <div className="grid grid-cols-2 gap-3.5">
        <div className="col-span-2">
          <Field label="Nombre / Razón Social *">
            <input className={SI} value={form.nombre} onChange={e => f('nombre', e.target.value)} placeholder="Juan Pérez o Courier Express SAC"/>
          </Field>
        </div>
        <Field label="Tipo">
          <select className={SEL} value={form.tipo} onChange={e => f('tipo', e.target.value)}>
            <option value="PROPIO">Propio (empleado/vehículo propio)</option>
            <option value="TERCERO">Tercero (empresa externa)</option>
          </select>
        </Field>
        <Field label="Placa del vehículo">
          <input className={SI} value={form.placa} onChange={e => f('placa', e.target.value.toUpperCase())} placeholder="ABC-123"/>
        </Field>
        <div className="col-span-2">
          <Field label="Descripción del vehículo">
            <input className={SI} value={form.vehiculo} onChange={e => f('vehiculo', e.target.value)} placeholder="Toyota Hilux, Van H-1, Moto..."/>
          </Field>
        </div>
        <Field label="Teléfono / Celular">
          <input className={SI} value={form.telefono} onChange={e => f('telefono', e.target.value)} placeholder="987-001-001"/>
        </Field>
        <Field label="Licencia de conducir">
          <input className={SI} value={form.licencia} onChange={e => f('licencia', e.target.value)} placeholder="Q84512301"/>
        </Field>
        <div className="col-span-2">
          <Field label="Email">
            <input type="email" className={SI} value={form.email} onChange={e => f('email', e.target.value)} placeholder="conductor@empresa.pe"/>
          </Field>
        </div>
      </div>
      <label className="flex items-center gap-2 cursor-pointer text-[13px] text-[#9ba8b6]">
        <input type="checkbox" checked={form.activo} onChange={e => f('activo', e.target.checked)} className="accent-[#00c896]"/>
        Transportista activo
      </label>
    </Modal>
  )
}
